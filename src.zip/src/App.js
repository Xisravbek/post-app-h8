import React, { useEffect } from 'react';
import Home from './pages/home/Home';
import {Route, Routes, useNavigate } from "react-router-dom"
import Login from './pages/login/Login';
import Register from './pages/register/Register';
import { useDispatch } from 'react-redux';
import PostId from './pages/postId/PostId';
import { axiosInstance } from './services/axiosInstance';
import { PostService } from './services/postService';
import { loginSuccess } from './store/slice/authSlice';



const App = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();


  const checkUser = async(token) => {
    try{
      const data = await PostService.showMyPosts(token);
      if(data) {
        dispatch(loginSuccess(JSON.parse(localStorage.getItem("user"))))
      }else navigate("/login");

    }catch (error) {
      console.log(error);
    }
  }


  useEffect(() => {
    let token = localStorage.getItem("token");
    checkUser(token)
  }, [])
  return (
    <>
  <Routes>
    <Route  path={"/*"} element={<Home />} />
    <Route path="/login" element={<Login/>} />
    <Route path='/register' element={<Register />} />
    <Route path='/post/:id' element={<PostId />} />
  </Routes>
    </>
  )
}

export default App