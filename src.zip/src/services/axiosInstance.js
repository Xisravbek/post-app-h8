import axios from "axios";

export const axiosInstance = axios.create({
    baseURL: "https://webstar-post-app.onrender.com/api"
})